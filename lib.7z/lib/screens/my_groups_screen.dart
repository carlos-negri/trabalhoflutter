import 'package:chamada/screens/register_group_screen.dart';
import 'package:flutter/material.dart';
import '../models/turma.dart';
import '../service/turma_service.dart';

class MyGroups extends StatefulWidget {
  const MyGroups ({super.key});

  @override
  _MyGroupsState createState() => _MyGroupsState();
}

class _MyGroupsState extends State<MyGroups>{
  final GroupService _groupService = GroupService();
  late Future<List<Group>> _groups;

  @override
  void initState(){
    super.initState();
    _groups = _groupService.getGroups();
  }

  void _refreshGroups(){
    setState(() {
      _groups=_groupService.getGroups();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Minhas turmas')),
      body: FutureBuilder<List<Group>>(
        future: _groups,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Erro: ${snapshot.error}'));
          }
          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final group = snapshot.data![index];
              return ListTile(
                title: Text(group.nivel),
                subtitle: Text(group.nomeTurma),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddGroupPage()),
          );
          _refreshGroups();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}